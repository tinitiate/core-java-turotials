package code.shark;

import java.awt.AWTException;
import java.awt.Robot;

public class MoveTest {

	public static void main(String[] args) throws InterruptedException {

		int sX = 0;
		int sY = 0;

		// TODO Auto-generated method stub
		while (true) {

			try {
				if (sX == 500) {
					sX = 0;
					sY = 0;
				}
				Thread.sleep(20000);
				// These coordinates are screen coordinates

			    // Move the cursor
			    Robot robot = new Robot();
			    robot.mouseMove(sX, sY);
			    sX++;
			    sY++;

			} catch (AWTException e) {
			}
		}
	}

}
