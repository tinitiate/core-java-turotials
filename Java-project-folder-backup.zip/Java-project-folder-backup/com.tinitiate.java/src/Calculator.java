
// Class Calculator
public class Calculator {

   // Data of Class Calculator
   int num1;
   int num2;
   
   // Methods of Class Calculator
   int Add() {
      return num1+num2;
   }
   
   // Methods of Class Calculator
   int Subtract() {
      return num1-num2;
   }

   // Methods of Class Calculator
   int Multiply() {
      return num1*num2;
   }

   int Divide() {
      return num1/num2;
   }

   
   // Main Method is a special method
   // This is used as an entry point 
   // into the program 
   public static void main(String[] args) {
      
      // Create an Object of the Class Calculator
      // ========================================
      Calculator Obj_1 = new Calculator();
      
      // Assign values to Class Variables
      Obj_1.num1 = 100;
      Obj_1.num2 = 50;
      
      // Call the Methods of the Class Calculator using the Object Obj_1 
      Obj_1.Add();
      Obj_1.Subtract();
      Obj_1.Multiply();
      Obj_1.Divide();


      // Create an Object of the Class Calculator
      // ========================================
      Calculator Obj_2 = new Calculator();
      
      // Assign values to Class Variables
      Obj_2.num1 = 100;
      Obj_2.num2 = 50;
      
      // Call the Methods of the Class Calculator using the Object Obj_1 
      Obj_2.Add();
      Obj_2.Subtract();
      Obj_2.Multiply();
      Obj_2.Divide();
   }
}
