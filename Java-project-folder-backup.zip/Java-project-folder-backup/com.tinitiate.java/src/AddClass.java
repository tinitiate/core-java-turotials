
// CREATE CLASS
public class AddClass {

   // CLASS FIELDS (variables)
   int num1;
   int num2;
   
   // CLASS METHODS
   public int Add() {
      return num1+num2; 
   }
  
   public static void main(String[] args) {
      
      // CREATE AN OBJECT
      AddClass addObject = new AddClass();
      
      // USING THE OBJECT
      // Assign values to addObject OBJECTs fields  
      addObject.num1 = 100;
      addObject.num1 = 200;

      // Use to addObject METHODs  
      System.out.println(addObject.Add());
   }
}



