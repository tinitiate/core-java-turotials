// >## jUnit Testing Exceptions using @Rule with "ExpectedException" rule
// >* In Junit, test suite allows us to aggregate all test cases from multiple classes in one place and run it together.
// >* To run the suite test, you need to annotate a class using below-mentioned annotations:
// >* @Runwith(Suite.class)
// >* @SuiteClasses(test1.class,test2.class��) or
// >* @Suite.SuiteClasses ({test1.class, test2.class��})

// >```
package tinitiate.junit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
   TestCalcMul.class,
   TestCalcAdd.class
})
public class TestSuite {

}
// >```