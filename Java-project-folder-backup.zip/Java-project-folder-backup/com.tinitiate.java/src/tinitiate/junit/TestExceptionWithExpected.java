// >## jUnit Testing Exceptions using @Test with "expected" attribute
// >* It is possible to trace exception handling of a Class Method using jUnit.
// >* This program demonstrates testing using @Test with "expected" attribute
// >* The "expected" attribute looks for the exception name.
// >```
package tinitiate.junit;

import org.junit.Test;

// === Step 1 ===
// Create a Custom Exception
// This will be used for capturing exception in jUnit.
// ---------------------------------------------------
class TinitiateException extends Exception {

   public TinitiateException() {
       super("This is a cusom execption.");
   }
}


public class TestExceptionWithExpected {
   
   // === Case 1 ===
   // Demonstrate junit exception testing using Built-in exception
   // ------------------------------------------------------------
   // 1. Intentionally divide by zero, this will raise an Arithmetic exception
   // 2. The annotation "@Test(expected = ArithmeticException.class)", 
   //    will capture the test case as failed.
   @Test(expected = ArithmeticException.class)
   public void testDivideByZero() {
      int num1 = 1/0;
   }


   // === Case 2 ===
   // Demonstrate junit exception testing using custom Exception
   // ----------------------------------------------------------
   // 1. Intentionally raise the custom exception, "TinitiateException"
   // 2. The annotation "@Test(expected =  TinitiateException.class)",
   //    will capture the test case as failed.
   @Test(expected = TinitiateException.class)
   public void testCustomException() throws TinitiateException {

      // Raise the TinitiateException()
      throw new TinitiateException();
   }
}
// >```
