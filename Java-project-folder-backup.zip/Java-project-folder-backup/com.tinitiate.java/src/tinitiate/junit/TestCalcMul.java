// >## Calc Class MUL method test case
// >* This is the test case for the mul() method
// >* This returns the product of two parameters num1, num2
// >* The **assertEquals** checks for an expected value with the value 
// >  that is returned by the MUL method.

// >```
package tinitiate.junit;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

@RunWith(JUnit4.class)
public class TestCalcMul {

   Calc Obj = new Calc();

   @Test
   public void testPrepareMyBag() {
      assertEquals(200, Obj.mul(10,20));
   }
}
// >```
