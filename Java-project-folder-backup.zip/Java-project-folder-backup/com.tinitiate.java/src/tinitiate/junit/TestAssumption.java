// >## JUnit Assumptions with Assume
// >* There could be scenarios where a decision to proceed or not to proceed 
// >  with testing depends on Environment setup, Version numbers, 
// >  dependencies on availability of network resource or certain locale.
// >```

package tinitiate.junit;

public class TestAssumption {

}
