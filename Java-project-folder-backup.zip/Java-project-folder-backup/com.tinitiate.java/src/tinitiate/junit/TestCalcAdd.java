// >## Calc Class ADD method test case
// >* This is the test case for the add() method
// >* This returns the sum of two parameters num1, num2
// >* The **assertEquals** checks for an expected value with the value 
// >  that is returned by the ADD method.

// >```
package tinitiate.junit;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

@RunWith(JUnit4.class)
public class TestCalcAdd {

   Calc Obj = new Calc();

   @Test
   public void testPrepareMyBag() {
      assertEquals(30, Obj.add(10,20));
   }
}
// >```