// >## Multiplier a Class that needs to be tested
// >* Consider the class Multiplier
// >* mul() method, This returns the product of two parameters num1, num2
// >* add() method, This returns the sum of two parameters num1, num2

// >```
// Class Adder, Adds TWO numbers and returns them
package tinitiate.junit;

public class Calc {

   // METHOD MUL
   // Member method of the class
   public int mul(int num1, int num2) {
      return num1*num2;
   }


   // METHOD ADD
   // Member method of the class
   public int add(int num1, int num2) {
      return num1+num2;
   }

}
// >```
