// >## A Class that needs to be tested
// >* Consider the class Adder
// >* Class Member variables
// >* Num1 and Num2, these are the variables that will be added
// >* Add() method, This returns  the sum of Num1, Num2

// >```
// Class Adder, Adds TWO numbers and returns them
package tinitiate.junit;

public class Adder {

   // Member fields of the class
   int num1;
   int num2;
   int num3;
   
   // Member method of the class
   public int Add() {
      return num1+num2;
   }
  
   // Member method of the class
   public int Add3Numbers() {
      return num1+num2+num3;
   }
   
}
// >```
