package tinitiate.junit;

// The java class LongRunningClass
// runNow() method intentionally takes 5 Secs to complete
public class LongRunningClass {

   // This method takes 5 Secs to execute
   public void RunNow() throws InterruptedException {
      Thread.sleep(5000);
   }
}
