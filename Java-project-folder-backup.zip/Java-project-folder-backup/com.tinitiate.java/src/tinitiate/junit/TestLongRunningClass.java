package tinitiate.junit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

@RunWith(JUnit4.class)
public class TestLongRunningClass {


   // The "timeout" parameter here is less than the time taken by RunNow() method.
   // This test will fail
   @Test(timeout=4000)
   public void testRunNowFail() {

      System.out.println("Test for RunNow start.");

      // Adder Class Object
      LongRunningClass obj = new LongRunningClass();

      // Execute the RunNow() 
      try {
         obj.RunNow();
      } catch (InterruptedException e) {
         e.printStackTrace();
      }

      System.out.println("Test for RunNow end.");
   }


   // The "timeout" parameter here is more than the time taken by RunNow() method.
   // This test will succeed
   @Test(timeout=6000)
   public void testRunNowPass() {

      System.out.println("Test for RunNow start.");

      // Adder Class Object
      LongRunningClass obj = new LongRunningClass();

      // Execute the RunNow() 
      try {
         obj.RunNow();
      } catch (InterruptedException e) {
         e.printStackTrace();
      }

      System.out.println("Test for RunNow end.");
   }
}
