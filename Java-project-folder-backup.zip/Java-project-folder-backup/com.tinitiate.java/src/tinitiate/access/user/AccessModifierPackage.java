// This is the package where the Default and Public from another package
// are called from.
package tinitiate.access.user;

// Import Classes with Default and Public from another package
import tinitiate.oop.AccessModifierPublicClass;

// Cannot import a Class Declared as Default
//import tinitiate.oop.AccessModifierDefaultClass;

// 1. This Class creates objects of the classes AccessModifierInheritance
//    and AccessModifierPublicClass from the Package "tinitiate.oop"
// 2. The Main method will access ONLY the Public constructor.
public class AccessModifierPackage {

   // This is the main function that starts the program to execute the process
   public static void main(String[] args) {
    
      // 1. creates objects of the classes AccessModifierInheritance, 
      //    Using ONLY the Public Constructor.
      AccessModifierPublicClass ObjPub = new AccessModifierPublicClass(1);

      // 2. Different package cannot use Private and Protected Constructor.
      //    Commenting the below lines will result in error.
      // AccessModifierPublicClass ObjPro = new AccessModifierPublicClass(); 
      // AccessModifierInheritance ObjPrv = new AccessModifierInheritance("test");

   }
}
