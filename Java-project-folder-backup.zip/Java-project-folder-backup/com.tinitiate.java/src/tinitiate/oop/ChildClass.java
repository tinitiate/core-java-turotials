// >### Single Inheritance
// >* Single Inheritance, One parent One Child
// >* The class that is inherited (Parent) is superclass.
// >* The class that does the inheriting (Child) is subclass.
// >* A subclass is specialized version of superclass.
// >* Subclass inherits all the instance variables and methods
// > of the superclass and could have its own variables and methods.
// >* SubClass cannot access PRIVATE members of SuperClass.

// >```
package tinitiate.oop;

// Parent Class
// This class that is one that gets inherited (Parent),
// the class that does the inheriting (Child) is subclass.
class ParentClass {

   // Parent Class Fields
   int ParentData1;
   int ParentData2;

   // Parent Class Method
   void parentSum() {
      System.out.println(ParentData1 + ParentData2);
   }
}

// Child Class
// The class that does the inheriting (Child) is subclass. It
// Inherits from SuperClass SuperClass by extending class
public class ChildClass extends ParentClass {

   // Child Class Fields
   int ChildData1;

   // Child Class Method
   void PrintChildData() {
      System.out.println(ChildData1);
   }

   // Use Parent Class Fields
   void PrintParentData() {
      System.out.println(ParentData1);
   }

   // Create the Object in the Main method
   public static void main(String[] args) {
      // Create an Object of Child Class
      ChildClass Object_child = new ChildClass();

      // Call CHILD CLASS Members using the CHILD CLASS OBJECT
      Object_child.ChildData1 = 10;
      Object_child.PrintChildData();

      // Call PARENT CLASS FIELDS using the CHILD CLASS OBJECT
      Object_child.ParentData1 = 35;
      Object_child.ParentData2 = 30;

      // Call PARENT CLASS METHOD using the CHILD CLASS OBJECT
      Object_child.parentSum();

   }
}
// >```
