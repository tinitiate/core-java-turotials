// >### COPY CONSTRUCTOR
// >* This is a **CONSTRUCTOR** that is used to make a copy of the
// > `CURRENT CLASS OBJECT`.
// >* Copying an Object is all about copying the Class Field Members
// > or Class variables, As the Class methods do not store any values.
// >* Copy constructor MUST have only one parameter, And must be the type of
// > its class.
// >* Making a copy of an Object using copy constructor works well only, if the
// > class mostly consists of mutable objects.
// >* Making copies of an Object is get complicated when there are Other
// > Objects, in the Class, Collections and non immutable member fields.
// >>
// >```
package tinitiate.oop;

public class CopyConstructorTest {

   // Class Member Fields
   int a;
   int b;

   // NORMAL CONSTRUCTOR
   public CopyConstructorTest(int a, int b) {
      this.a = a;
      this.b = b;
   }

   // COPY CONSTRUCTOR
   public CopyConstructorTest(CopyConstructorTest c) {
      // Assign the current object values of the Input Object "c" 's
      // to the Member fields
      a = c.a;
      b = c.b;
   }

   public static void main(String[] args) {

      // Creating an Object Copy using COPY CONSTRUCTOR
      // ==============================================
      // Create an Object C1
      CopyConstructorTest C1 = new CopyConstructorTest(10, 20);

      // Current Member field values of Object C1
      System.out.println("C1 Object Member Field Values: " + C1.a + " " + C1.b);

      // Call the COPY CONSTRUCTOR to make an Object Copy
      // The following will copy Object C1 to object C2
      CopyConstructorTest C2 = new CopyConstructorTest(C1);

      // Current Member field values of Object C2
      System.out.println("C2 Object Member Field Values: " + C2.a + " " + C2.b);

   }
}
// >```