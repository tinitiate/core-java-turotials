
package tinitiate.oop;

public class MethodClass {

   int num1;
   int num2;

   public void Greetings() {
      System.out.println("Hello Tinitiate");
   }

   public int Add() {
      return this.num1 + this.num2;
   }

   public int Add(int num1, int num2) {
      return num1 + num2;
   }

   public static void main(String[] args) {

      MethodClass Obj = new MethodClass();

      Obj.Greetings();
      Obj.Add(10, 20);

      Obj.num1 = 11;
      Obj.num2 = 22;
      Obj.Add();
   }
}
