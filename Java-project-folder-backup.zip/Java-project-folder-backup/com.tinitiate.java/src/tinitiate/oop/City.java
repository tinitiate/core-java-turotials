// >### Multilevel Inheritance
// >* Class order, Grand-Parent Parent Child
// >* A Grand-Parent class members can be inherited by a Parent class,
// > and inturn the parent class members can be inherited in the child class,
// > This makes the Child class access the Grand parent class'es member
// > fields and methods.
// >>
// >* Program to demonstrate Multilevel Hierarchy, with inheritance
// >* CountryClass, is the level-1 Parent
// >* StateClass, is the level-2 Parent that inherits from CountryClass
// >* CityClass, is the Child that inherits from StateClass
// >>
// >```
package tinitiate.oop;

// Grand Parent (Parent's Parent) Level Class
class Country {
   String CountryName;

   public void PrintCountryName() {
      System.out.println("CountryClass Message, Country Name: " + CountryName);
   }
}

// Parent Class
class State extends Country {
   String StateName;

   public void PrinStateName() {
      System.out.println("StateClass Message, State Name: " + StateName);
   }
}

// Child Class
public class City extends State {
   String CityName;

   public void PrintCityName() {
      System.out.println("CityClass Message, City Name: " + CityName);
   }

   public static void main(String[] args) {
      // Create Child Class Object
      // City Class Object
      City ObjCity = new City();

      // Assign value to Country Class Member
      ObjCity.CountryName = "USA";
      // Assign value to State Class Member
      ObjCity.StateName = "New York";
      // Assign value to City Class Member
      ObjCity.CityName = "New York City";

      // Country Class Method
      ObjCity.PrintCountryName();
      // State Class Method
      ObjCity.PrinStateName();
      // City Class Method
      ObjCity.PrintCityName();
   }
}
// >```
