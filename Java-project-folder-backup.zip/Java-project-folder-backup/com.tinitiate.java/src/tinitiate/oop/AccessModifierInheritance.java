// * This is the package where the AccessSpecifierPublicClass and the
// AccessModifierDefaultClass Class are Inherited Along with all is CLASS
// MEMBERs
package tinitiate.oop;

// This CLASS inherits the DEFAULT CLASS
class AccessModifierInheritanceTest extends AccessModifierDefaultClass {

   public void CallDefaultClassMembers() {

      // 1. Inheritance and access of DEFAULT MEMBERS
      varDEFAULT_1 = 1;
      MethodDEFAULT_1();

      // 2. Inheritance and access of PROTECTED MEMBERS
      varPROTECTED_1 = 1;
      MethodPROTECTED_1();

      // 3. Inheritance and access of PUBLIC MEMBERS
      varPUBLIC_1 = 1;
      MethodPUBLIC_1();

      // 4. Inheritance and access of PRIVATE MEMBERS is NOT ALLOWED
      // varPRIVATE_1 = 1;
      // MethodPRIVATE_1();
   }
}

// This CLASS inherits the PUBLIC CLASS
public class AccessModifierInheritance extends AccessModifierPublicClass {

   public void CallDefaultClassMembers() {

      // 1. Inheritance and access of DEFAULT MEMBERS
      varDEFAULT_2 = 1;
      MethodDEFAULT_2();

      // 2. Inheritance and access of PROTECTED MEMBERS
      varPROTECTED_2 = 1;
      MethodPROTECTED_2();

      // 3. Inheritance and access of PUBLIC MEMBERS
      varPUBLIC_2 = 1;
      MethodPUBLIC_2();

      // 4. Inheritance and access of PRIVATE MEMBERS is NOT ALLOWED
      // varPRIVATE_1 = 1;
      // MethodPRIVATE_1();
   }

}
