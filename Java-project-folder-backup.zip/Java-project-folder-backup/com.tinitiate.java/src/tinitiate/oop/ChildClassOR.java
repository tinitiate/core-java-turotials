package tinitiate.oop;

class ParentClassOR {
   public void MethodA() {
      System.out
            .println("This is || Class: ParentClassOR || Method: MethodA ||");
   }
}

public class ChildClassOR extends ParentClassOR {
   @Override
   public void MethodA() {
      System.out.println(
            "This is OverRidden || Class: ChildClassOR || Method: MethodA ||");
   }

   public void SuperMethodsCall(String CountryName, String population,
         String LandAreaSize) {

      super.MethodA(); // This executes the ParentClassOR.MethodA()
   }
}
