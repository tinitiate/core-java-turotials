// >### Inheritance SUPER Keyword
// >* There could be situations where the Parent Class could have the same
// > member names as the Child Class.
// >* In such situations the keyword "super" is used to refer to a
// > Parent Class fields and methods.
// >* These same name "name conflicts" is usually common with Methods,
// > called as method overriding.
// >* 1) The class that is inherited (Parent) is superclass.
// >* 2) The class that does the inheriting (Child) is subclass.
// >* 3) "super" Keyword Operates in TWO modes,
// > * (3.a) Calls the superclass constructor.
// > * (3.b) Can be used to access hidden by a member of the superclass in
// subclass.
// >>

// >```
package tinitiate.oop;

// SuperClass - The Parent Class
class SuperClass {

   // SuperClass Member Field and Method
   int SuperClassVar;

   void SC_Message() {
      System.out.println("Have a Great Day !");
   }

   // SuperClass Constructor
   public SuperClass() {
      System.out.println("Message from SuperClass Constructor!");
   }
}

// SubClass - The Child Class
// Inherit the SuperClass
class SubClass extends SuperClass {

   // SubClass Member Field and Method
   int VarSubClass;

   public void SubClassMethod(int x) {

      // ===========================================
      // Call the SuperClass using the SUPER keyword
      // ===========================================
      // Call the SuperClass Member Field
      super.SuperClassVar = x;
      // SuperClass Member Method
      super.SC_Message();

   }
}

// The CLASS with the MAIN method to call the SubClass Object
public class SuperKeyword {

   public static void main(String[] args) {

      // SubClass Object
      SubClass subObj = new SubClass();

      // Call the SubClass Variable using the SubClass Object
      subObj.VarSubClass = 100;
      // Call the SubClass Method using the SubClass Object
      subObj.SubClassMethod(20);

      // Call the SuperClass Variable using the SubClass Object
      subObj.SuperClassVar = 100;
      // Call the SuperClass Method using the SubClass Object
      subObj.SC_Message();
   }
}
// >```
