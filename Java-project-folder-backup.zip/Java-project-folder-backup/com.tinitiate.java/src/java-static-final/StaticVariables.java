// >---
// >YamlDesc: CONTENT-ARTICLE
// >Title: java static variables
// >MetaDescription: 'java static variables'
// >MetaKeywords: 'java static variables example code, tutorials'
// >Author: Venkata Bhattaram / tinitiate.com
// >ContentName: static-variables
// >---
// >* Static Variables are variables whose values can be used anywhere in the 
// >  program without the need to create an Object.

package tinitiate.introduction;

public class StaticVariables {

   // STATIC VARIABLES
   // Values assigned to them WILL NOT change values through out the program
   static int i;    // Declaration, but no initialization of i
   static int j=20; // Declaration and Initialization of j
   
   public static void main(String[] args) {
      // TODO Auto-generated method stub

      // Topic 1.
      // Initialize the STATIC VARIABLE "i" and Print its value
      // ======================================================
      i=100;
      System.out.println("Value of i is: " + i);
   }
}
