// >---
// >YamlDesc: CONTENT-ARTICLE
// >Title: java variable scope
// >MetaDescription: 'java variable scope'
// >MetaKeywords: 'java variable scope example code, tutorials'
// >Author: Venkata Bhattaram / tinitiate.com
// >ContentName: variable-scope
// >---

// ># Java Variable Scope for
// >* Variable scope defines the extent unto which the variable 
// >  can be accessible with in the class. 
// >* Global variables
// >  * Access global variables of a class from static 
// >    method using an object of the class.
// >* Static Variables 
// >  * Access static variables anywhere in the class without 
// >    the need to create an Object.
// >* Local variables
// >  * Access local variables anywhere in the method where they are declared.

// >```
package tinitiate.introduction;

public class VariableScope {

   // Global Variable
   // This is a class variable that can be read by creating an object
   int gData = 100;

   // Static variable
   static int sData = 99;
   
   // Class method
   public void scopeTest() {
      
      // Read Global variables from NON STATIC class method
      // ==================================================
      // * scopeTest method is non-static
      // * Read Non Static Class variables, directly 
      //   without the need of creating an object.
      System.out.println("ObjectLess Global variable: " + gData);

      
      // Reading Static variable from NON STATIC method
      // ==============================================
      // * To read Static Class variables it is not 
      //   required to create a class object,
      //   they can be read directly. 
      System.out.println("Global static variable: " + sData);
      
   }
   

   // Main method
   public static void main(String[] args) {
      
      // Read Global variables from STATIC class method
      // ==============================================
      // * Main method is static
      // * Read Non Static Class variables,
      //   by creating a class object

      // Create an object of class VariableScope
      VariableScope Obj = new VariableScope();
      
      // Read Global variable from the object
      System.out.println("Global variable: " + Obj.gData);
      
      
      // Reading Static variable from STATIC method
      // ==========================================
      // * To read Static Class variables it is not 
      //   required to create a class object,
      //   they can be read directly. 
      System.out.println("Global static variable: " + sData);

      
      // Creating and using Local variable
      // =================================
      // * Local variables are created inside the a method.
      // * They can be referenced any where in the same method.
      // * They cannot be referenced outside the method.
      int lData = 66;
      System.out.println("Local variable: " + lData);
   }

}
// >```
